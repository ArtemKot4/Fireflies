ConfigureMultiplayer({
    isClientOnly: false
});

Launch();