"use strict";
var ESide;
(function (ESide) {
    ESide[ESide["CLIENT"] = 0] = "CLIENT";
    ESide[ESide["SERVER"] = 1] = "SERVER";
})(ESide || (ESide = {}));
var RuntimeData;
(function (RuntimeData) {
    /**
     * Screen name on client.
     */
    var local;
    (function (local) {
        local.screenName = null;
    })(local = RuntimeData.local || (RuntimeData.local = {}));
})(RuntimeData || (RuntimeData = {}));
var MathHelper;
(function (MathHelper) {
    function randomFrom() {
        var elements = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            elements[_i] = arguments[_i];
        }
        return elements[Math.floor(Math.random() * elements.length)];
    }
    MathHelper.randomFrom = randomFrom;
    function randomFromArray(array) {
        return array[Math.floor(Math.random() * array.length)];
    }
    MathHelper.randomFromArray = randomFromArray;
    function radian(gradus) {
        return (gradus * Math.PI) / 180;
    }
    MathHelper.radian = radian;
    function randomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    MathHelper.randomNumber = randomNumber;
    function range(min, max, step) {
        if (step === void 0) { step = 1; }
        var list = [];
        for (var i = min; i < max; i += step) {
            list.push(i);
        }
        return list;
    }
    MathHelper.range = range;
})(MathHelper || (MathHelper = {}));
var TileEntity;
(function (TileEntity) {
    function buildEvents(prototype) {
        if ("eventNames" in prototype) {
            prototype.events = {};
            prototype.containerEvents = {};
            for (var i in prototype.eventNames.network) {
                var name = prototype.eventNames.network[i];
                prototype.events[name] = prototype[name];
            }
            for (var i in prototype.eventNames.container) {
                var name = prototype.eventNames.container[i];
                prototype.containerEvents[name] = prototype[name];
            }
        }
    }
    TileEntity.buildEvents = buildEvents;
    function openFor(client, tile) {
        if (tile != null) {
            var screenName = tile.getScreenName(client.getPlayerUid(), new Vector3(tile.x, tile.y, tile.z));
            if (screenName != null) {
                tile.container.openFor(client, screenName);
            }
        }
    }
    TileEntity.openFor = openFor;
})(TileEntity || (TileEntity = {}));
var ToolAPI;
(function (ToolAPI) {
    function isAxe(item) {
        var _a, _b;
        return (_b = (_a = ToolAPI.getToolData(item)) === null || _a === void 0 ? void 0 : _a.blockMaterials) === null || _b === void 0 ? void 0 : _b["wood"];
    }
    ToolAPI.isAxe = isAxe;
    function isPickaxe(item) {
        var _a, _b;
        return (_b = (_a = ToolAPI.getToolData(item)) === null || _a === void 0 ? void 0 : _a.blockMaterials) === null || _b === void 0 ? void 0 : _b["stone"];
    }
    ToolAPI.isPickaxe = isPickaxe;
    function isShovel(item) {
        var _a, _b;
        return (_b = (_a = ToolAPI.getToolData(item)) === null || _a === void 0 ? void 0 : _a.blockMaterials) === null || _b === void 0 ? void 0 : _b["dirt"];
    }
    ToolAPI.isShovel = isShovel;
    function isHoe(item) {
        var _a, _b;
        return (_b = (_a = ToolAPI.getToolData(item)) === null || _a === void 0 ? void 0 : _a.blockMaterials) === null || _b === void 0 ? void 0 : _b["farmland"];
    }
    ToolAPI.isHoe = isHoe;
})(ToolAPI || (ToolAPI = {}));
var Block;
(function (Block) {
    Block.destroyFunctions = {};
    Block.destroyStartFunctions = {};
    Block.destroyContinueFunctions = {};
    Block.projectileHitFunctions = {};
    Block.selectionFunctions = {};
    function createPlantBlock(nameID, defineData) {
        new BlockPlant(nameID, defineData);
    }
    Block.createPlantBlock = createPlantBlock;
    function setEmptyCollisionShape(id) {
        var render = new ICRender.Model();
        var model = BlockRenderer.createModel();
        var shape = new ICRender.CollisionShape();
        var entry = shape.addEntry();
        entry.addBox(0, 0, 0, 0, 0, 0);
        BlockRenderer.setCustomCollisionShape(id, -1, shape);
        render.addEntry(model);
    }
    Block.setEmptyCollisionShape = setEmptyCollisionShape;
    function setSolid(id, solid) {
        com.zhekasmirnov.innercore.api.NativeBlock.setSolid(id, solid);
    }
    Block.setSolid = setSolid;
    function setRenderAllFaces(id, render) {
        com.zhekasmirnov.innercore.api.NativeBlock.setRenderAllFaces(id, render);
    }
    Block.setRenderAllFaces = setRenderAllFaces;
    function setRenderType(id, type) {
        com.zhekasmirnov.innercore.api.NativeBlock.setRenderType(id, type);
    }
    Block.setRenderType = setRenderType;
    function setRenderLayer(id, layer) {
        com.zhekasmirnov.innercore.api.NativeBlock.setRenderLayer(id, layer);
    }
    Block.setRenderLayer = setRenderLayer;
    function setLightLevel(id, level) {
        com.zhekasmirnov.innercore.api.NativeBlock.setLightLevel(id, level);
    }
    Block.setLightLevel = setLightLevel;
    function setLightOpacity(id, opacity) {
        com.zhekasmirnov.innercore.api.NativeBlock.setLightOpacity(id, opacity);
    }
    Block.setLightOpacity = setLightOpacity;
    function setExplosionResistance(id, resistance) {
        com.zhekasmirnov.innercore.api.NativeBlock.setExplosionResistance(id, resistance);
    }
    Block.setExplosionResistance = setExplosionResistance;
    function setFriction(id, friction) {
        com.zhekasmirnov.innercore.api.NativeBlock.setFriction(id, friction);
    }
    Block.setFriction = setFriction;
    function setTranslucency(id, translucency) {
        com.zhekasmirnov.innercore.api.NativeBlock.setTranslucency(id, translucency);
    }
    Block.setTranslucency = setTranslucency;
    function setSoundType(id, type) {
        com.zhekasmirnov.innercore.api.NativeBlock.setSoundType(id, type);
    }
    Block.setSoundType = setSoundType;
    function setMapColor(id, color) {
        com.zhekasmirnov.innercore.api.NativeBlock.setMapColor(id, color);
    }
    Block.setMapColor = setMapColor;
    function setBlockColorSource(id, source) {
        com.zhekasmirnov.innercore.api.NativeBlock.setBlockColorSource(id, source);
    }
    Block.setBlockColorSource = setBlockColorSource;
    function setMaterialBase(id, base_id) {
        com.zhekasmirnov.innercore.api.NativeBlock.setMaterialBase(id, base_id);
    }
    Block.setMaterialBase = setMaterialBase;
    function registerDestroyFunction(id, func) {
        Block.destroyFunctions[typeof id == "string" ? IDRegistry.parseBlockID(id) : id] = func;
    }
    Block.registerDestroyFunction = registerDestroyFunction;
    function registerDestroyFunctionForID(id, func) {
        Block.destroyFunctions[id] = func;
    }
    Block.registerDestroyFunctionForID = registerDestroyFunctionForID;
    function registerDestroyStartFunction(id, func) {
        Block.destroyStartFunctions[typeof id == "string" ? IDRegistry.parseBlockID(id) : id] = func;
    }
    Block.registerDestroyStartFunction = registerDestroyStartFunction;
    function registerDestroyStartFunctionForID(id, func) {
        Block.destroyStartFunctions[id] = func;
    }
    Block.registerDestroyStartFunctionForID = registerDestroyStartFunctionForID;
    function registerDestroyContinueFunction(id, func) {
        Block.destroyContinueFunctions[typeof id == "string" ? IDRegistry.parseBlockID(id) : id] = func;
    }
    Block.registerDestroyContinueFunction = registerDestroyContinueFunction;
    function registerDestroyContinueFunctionForID(id, func) {
        Block.destroyContinueFunctions[id] = func;
    }
    Block.registerDestroyContinueFunctionForID = registerDestroyContinueFunctionForID;
    function registerProjectileHitFunction(id, func) {
        Block.projectileHitFunctions[id] = func;
    }
    Block.registerProjectileHitFunction = registerProjectileHitFunction;
    function registerSelectionFunction(id, func) {
        Block.selectionFunctions[id] = func;
    }
    Block.registerSelectionFunction = registerSelectionFunction;
    function registerSelectionFunctionForID(id, func) {
        Block.selectionFunctions[typeof id == "string" ? IDRegistry.parseBlockID(id) : id];
    }
    Block.registerSelectionFunctionForID = registerSelectionFunctionForID;
    Callback.addCallback("DestroyBlockContinue", function (coords, block, progress) {
        var blockFunction = Block.destroyContinueFunctions[block.id];
        if (blockFunction != null) {
            return blockFunction(coords, block, progress);
        }
    });
    Callback.addCallback("DestroyBlockStart", function (coords, block, player) {
        var blockFunction = Block.destroyStartFunctions[block.id];
        if (blockFunction != null) {
            return blockFunction(coords, block, player);
        }
    });
    Callback.addCallback("DestroyBlock", function (coords, block, player) {
        var blockFunction = Block.destroyFunctions[block.id];
        if (blockFunction != null) {
            return blockFunction(coords, block, player);
        }
    });
    Callback.addCallback("ProjectileHit", function (projectile, item, target) {
        var projectileHitFunction = Block.projectileHitFunctions[BlockSource.getDefaultForActor(projectile).getBlockID(target.coords.x, target.coords.y, target.coords.z)];
        if (projectileHitFunction != null) {
            return projectileHitFunction(projectile, new ItemStack(item), target);
        }
    });
    Callback.addCallback("Selection", function (viewVector, blockPosition, entityUid, block) {
        var selectionFunction = Block.selectionFunctions[block.id];
        if (selectionFunction != null) {
            return selectionFunction(block, blockPosition, viewVector);
        }
        var tile = TileEntity.getTileEntity(blockPosition.x, blockPosition.y, blockPosition.z);
        if (tile != null && "client" in tile && "selection" in tile.client) {
            return tile.onSelection();
        }
    });
})(Block || (Block = {}));
var Item;
(function (Item) {
    Item.holdFunctions = {};
    function registerHoldFunctionForID(id, func) {
        Item.holdFunctions[id] = func;
    }
    Item.registerHoldFunctionForID = registerHoldFunctionForID;
    function registerHoldFunction(id, func) {
        Item.holdFunctions[typeof id == "string" ? IDRegistry.parseID(id) : id] = func;
    }
    Item.registerHoldFunction = registerHoldFunction;
    function createLiquidStorageItem(nameID, name, texture, params, data) {
        if (data === void 0) { data = 0; }
        Item.createItem(nameID, name, texture, params);
        LiquidItemRegistry.registerLiquidStorage(IDRegistry.parseItemID(nameID), data, params);
    }
    Item.createLiquidStorageItem = createLiquidStorageItem;
})(Item || (Item = {}));
Callback.addCallback("ItemHold", function (item, playerUid, slotIndex) {
    var holdFunction = Item.holdFunctions[item.id];
    if (holdFunction != null) {
        return holdFunction(item, playerUid, slotIndex);
    }
});
var World;
(function (World) {
    function getDifficulty() {
        return com.zhekasmirnov.innercore.api.NativeAPI.getDifficulty();
    }
    World.getDifficulty = getDifficulty;
    function setDifficulty(difficulty) {
        com.zhekasmirnov.innercore.api.NativeAPI.setDifficulty(difficulty);
    }
    World.setDifficulty = setDifficulty;
    function resetCloudColor() {
        com.zhekasmirnov.innercore.api.NativeAPI.resetCloudColor();
    }
    World.resetCloudColor = resetCloudColor;
    function resetFogColor() {
        com.zhekasmirnov.innercore.api.NativeAPI.resetFogColor();
    }
    World.resetFogColor = resetFogColor;
    function resetFogDistance() {
        com.zhekasmirnov.innercore.api.NativeAPI.resetFogDistance();
    }
    World.resetFogDistance = resetFogDistance;
    function resetSkyColor() {
        com.zhekasmirnov.innercore.api.NativeAPI.resetSkyColor();
    }
    World.resetSkyColor = resetSkyColor;
    function resetSunsetColor() {
        com.zhekasmirnov.innercore.api.NativeAPI.resetSunsetColor();
    }
    World.resetSunsetColor = resetSunsetColor;
    function resetUnderwaterFogColor() {
        com.zhekasmirnov.innercore.api.NativeAPI.resetUnderwaterFogColor();
    }
    World.resetUnderwaterFogColor = resetUnderwaterFogColor;
    function resetUnderwaterFogDistance() {
        com.zhekasmirnov.innercore.api.NativeAPI.resetUnderwaterFogDistance();
    }
    World.resetUnderwaterFogDistance = resetUnderwaterFogDistance;
    function setFogColor(r, g, b) {
        com.zhekasmirnov.innercore.api.NativeAPI.setFogColor(r, g, b);
    }
    World.setFogColor = setFogColor;
    function setSkyColor(r, g, b) {
        com.zhekasmirnov.innercore.api.NativeAPI.setSkyColor(r, g, b);
    }
    World.setSkyColor = setSkyColor;
    function setSunsetColor(r, g, b) {
        com.zhekasmirnov.innercore.api.NativeAPI.setSunsetColor(r, g, b);
    }
    World.setSunsetColor = setSunsetColor;
    function setUnderwaterFogColor(r, g, b) {
        com.zhekasmirnov.innercore.api.NativeAPI.setUnderwaterFogColor(r, g, b);
    }
    World.setUnderwaterFogColor = setUnderwaterFogColor;
    function setUnderwaterFogDistance(r, g, b) {
        com.zhekasmirnov.innercore.api.NativeAPI.setUnderwaterFogDistance(r, g, b);
    }
    World.setUnderwaterFogDistance = setUnderwaterFogDistance;
    function setFogDistance(r, g, b) {
        com.zhekasmirnov.innercore.api.NativeAPI.setFogDistance(r, g, b);
    }
    World.setFogDistance = setFogDistance;
    function setCloudColor(r, g, b) {
        com.zhekasmirnov.innercore.api.NativeAPI.setCloudColor(r, g, b);
    }
    World.setCloudColor = setCloudColor;
})(World || (World = {}));
var TagRegistry;
(function (TagRegistry) {
    function getBlockTags(id) {
        return TagRegistry.getTagsFor("blocks", id);
    }
    TagRegistry.getBlockTags = getBlockTags;
    function getItemTags(id) {
        return TagRegistry.getTagsFor("items", id);
    }
    TagRegistry.getItemTags = getItemTags;
    function getDimensionTags(id) {
        return TagRegistry.getTagsFor("dimensions", id);
    }
    TagRegistry.getDimensionTags = getDimensionTags;
})(TagRegistry || (TagRegistry = {}));
var IDRegistry;
(function (IDRegistry) {
    /**
     * Method to get valid block id: block id or vanilla block id
     * @param id any block id
     */
    function parseBlockID(id) {
        return BlockID[id] || VanillaBlockID[id];
    }
    IDRegistry.parseBlockID = parseBlockID;
    /**
     * Method to get valid item id: item id or vanilla item id
     * @param id any item id
     */
    function parseItemID(id) {
        return ItemID[id] || VanillaItemID[id];
    }
    IDRegistry.parseItemID = parseItemID;
    /**
     * Method to get valid block or item id
     * @param id any id of block or item
     */
    function parseID(id) {
        var _a;
        return (_a = parseBlockID(id)) !== null && _a !== void 0 ? _a : parseItemID(id);
    }
    IDRegistry.parseID = parseID;
})(IDRegistry || (IDRegistry = {}));
var LiquidItemRegistry;
(function (LiquidItemRegistry) {
    LiquidItemRegistry.storage = {};
    function registerLiquidStorage(id, data, description) {
        data = data == -1 ? 0 : data;
        var key = (id + ":" + data);
        if (getLiquidStorage(id, data) != null) {
            throw new Error("Item liquid storage by \"".concat(key, "\" already registered"));
        }
        LiquidItemRegistry.storage[key] = description;
    }
    LiquidItemRegistry.registerLiquidStorage = registerLiquidStorage;
    function getLiquidStorage(id, data) {
        return LiquidItemRegistry.storage[id + ":" + (data == -1 ? 0 : data)] || null;
    }
    LiquidItemRegistry.getLiquidStorage = getLiquidStorage;
    function getCapacity(id, data) {
        return getLiquidStorage(id, data).capacity || 0;
    }
    LiquidItemRegistry.getCapacity = getCapacity;
    function getLiquids(id, data) {
        return getLiquidStorage(id, data).liquids || [];
    }
    LiquidItemRegistry.getLiquids = getLiquids;
    function getCurrentLiquid(extra) {
        if (extra == null) {
            return null;
        }
        return extra.getString("liquid.name");
    }
    LiquidItemRegistry.getCurrentLiquid = getCurrentLiquid;
    function getCurrentLiquidCapacity(extra) {
        if (extra == null) {
            return null;
        }
        return extra.getInt("liquid.capacity", 0);
    }
    LiquidItemRegistry.getCurrentLiquidCapacity = getCurrentLiquidCapacity;
})(LiquidItemRegistry || (LiquidItemRegistry = {}));
var UI;
(function (UI) {
    UI.FontManager = com.artemkot4.fireflies.ui.utils.FontManager;
    // export namespace FontManager {
    //     export function registerTypeface(typeface: android.graphics.Typeface, name: string): android.graphics.Typeface {
    //         return com.artemkot4.fireflies.ui.utils.FontManager.registerTypeface(typeface, name);
    //     }
    //     export function registerTypefacesFrom(path: string): void {
    //         com.artemkot4.fireflies.ui.utils.FontManager.registerTypefacesFrom(path);
    //     }
    //     export function registerTypefaceFrom(path: string, name: string) {
    //         com.artemkot4.fireflies.ui.utils.FontManager.registerTypefaceFrom(path, name);
    //     }
    //     export function getTypeface(name: string): Nullable<android.graphics.Typeface> {
    //         return com.artemkot4.fireflies.ui.utils.FontManager.getTypeface(name);
    //     }
    //     export function getTypefaceSafe(name: string): android.graphics.Typeface {
    //         return com.artemkot4.fireflies.ui.utils.FontManager.getTypefaceSafe(name);
    //     }
    // }
    var FONT_TYPESPACES;
    (function (FONT_TYPESPACES) {
        FONT_TYPESPACES.MINECRAFT = UI.FontManager.getTypeface("minecraft");
        FONT_TYPESPACES.DEFAULT = android.graphics.Typeface.DEFAULT;
        FONT_TYPESPACES.DEFAULT_BOLD = android.graphics.Typeface.DEFAULT_BOLD;
        FONT_TYPESPACES.MONOSPACE = android.graphics.Typeface.MONOSPACE;
        FONT_TYPESPACES.SANS_SERIF = android.graphics.Typeface.SANS_SERIF;
        FONT_TYPESPACES.SERIF = android.graphics.Typeface.SERIF;
    })(FONT_TYPESPACES = UI.FONT_TYPESPACES || (UI.FONT_TYPESPACES = {}));
})(UI || (UI = {}));
//test
// UI.FontManager.registerTypefacesFrom(__dir__ + "resources/assets/gui/");
// UI.FontManager.registerTypefaceFrom(__dir__ + "resources/assets/gui/goth.ttf", "aboba");
// Callback.addCallback("ItemUse", (c,i) => {
//     if(i.id == VanillaItemID.stick) {
//         const ui = new UI.Window({
//             "drawing": [
//                 {
//                     type: "background",
//                     color: android.graphics.Color.TRANSPARENT
//                 }
//             ],
//             "elements": {
//                 "aboba": {
//                     x: 35,
//                     y: 50,
//                     type: "text",
//                     text: "Проверка прекрасного текста",
//                     font: {
//                         size: 50,
//                         typeface: "aboba",
//                         color: android.graphics.Color.BLACK,
//                     }
//                 },
//                 "aboba2": {
//                     x: 35,
//                     y: 90,
//                     type: "text",
//                     text: "Сегодня хороший день",
//                     font: {
//                         size: 50,
//                         typeface: "goth",
//                         color: android.graphics.Color.BLACK,
//                     }
//                 },
//                 "aboba3": {
//                     x: 35,
//                     y: 130,
//                     type: "text",
//                     text: "Это должен быть обычный шрифт",
//                     font: {
//                         size: 30,
//                         color: android.graphics.Color.BLACK,
//                     }
//                 }
//             }
//         });
//         ui.setTouchable(false);
//         ui.open();
//     }
// })
var RenderHelper;
(function (RenderHelper) {
    function generateMesh(dir, model, params, rotate) {
        if (params === void 0) { params = { translate: [0.5, 0.5, 0.5], invertV: false, noRebuild: false }; }
        var mesh = new RenderMesh(dir + model + ".obj", "obj", params);
        if (rotate != null) {
            mesh.rotate(rotate[0], rotate[1], rotate[2]);
        }
        return mesh;
    }
    RenderHelper.generateMesh = generateMesh;
})(RenderHelper || (RenderHelper = {}));
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var WorldRenderObject = /** @class */ (function () {
    function WorldRenderObject(x, y, z) {
        var _a;
        var _b;
        this.loaded = false;
        this.animation = new Animation.Base(x, y, z);
        this.x = x;
        this.y = y;
        this.z = z;
        var lightMode = this.getLightMode();
        if (lightMode != null) {
            switch (lightMode) {
                case "block": {
                    this.animation.setBlocklightMode();
                }
                case "skylight": {
                    this.animation.setSkylightMode();
                }
                case "ignore": {
                    this.animation.setIgnoreLightMode();
                }
            }
        }
        var id = this.getStringID();
        (_a = (_b = WorldRenderObject.objects)[id]) !== null && _a !== void 0 ? _a : (_b[id] = {});
    }
    WorldRenderObject.prototype.getDescription = function () {
        var describeObject = {};
        var render = this.getRender();
        var mesh = this.getRenderMesh();
        var skin = this.getSkin();
        var material = this.getMaterial();
        if (render != null) {
            describeObject.render = render.getId();
        }
        if (mesh != null) {
            describeObject.mesh = mesh;
        }
        if (skin != null) {
            describeObject.skin = skin;
        }
        if ("scale" in this) {
            describeObject.scale = this.renderScale;
        }
        if (material != null) {
            describeObject.material = material;
        }
        return describeObject;
    };
    /** Id for thread name if need
     */
    WorldRenderObject.prototype.getStringID = function () {
        return "fireflies.basic";
    };
    WorldRenderObject.prototype.getRenderMesh = function () {
        return null;
    };
    WorldRenderObject.prototype.getRender = function () {
        return null;
    };
    WorldRenderObject.prototype.getSkin = function () {
        return this.skin;
    };
    WorldRenderObject.prototype.getLightMode = function () {
        return null;
    };
    WorldRenderObject.prototype.getMaterial = function () {
        return null;
    };
    /**
     * Loads render object in world and puts it to the storage by id and uuid
     */
    WorldRenderObject.prototype.load = function () {
        var _a;
        if (this.loaded == true) {
            return;
        }
        this.animation.describe(this.getDescription());
        this.animation.load();
        this.loaded = true;
        (_a = this.uuid) !== null && _a !== void 0 ? _a : (this.uuid = String(java.util.UUID.randomUUID()));
        WorldRenderObject.objects[this.getStringID()][this.uuid] = this;
        if ("run" in this) {
            this.startThread();
        }
        return;
    };
    WorldRenderObject.prototype.refresh = function () {
        this.animation.refresh();
    };
    WorldRenderObject.prototype.startThread = function () {
        var _this = this;
        var sleepTime = 1000 / this.getFps();
        if (this.thread != null) {
            this.thread.stop();
        }
        this.threadInited = true;
        this.thread = Threading.initThread("thread." + this.getStringID(), function () {
            while (_this.threadInited == true) {
                java.lang.Thread.sleep(sleepTime);
                _this.run();
            }
        });
    };
    WorldRenderObject.prototype.getFps = function () {
        return 50;
    };
    WorldRenderObject.prototype.stop = function () {
        this.threadInited = false;
    };
    WorldRenderObject.prototype.start = function () {
        this.threadInited = true;
    };
    WorldRenderObject.prototype.destroy = function () {
        this.animation.destroy();
        this.loaded = false;
        this.threadInited = false;
        delete WorldRenderObject.objects[this.getStringID()][this.uuid];
    };
    WorldRenderObject.prototype.rotate = function (x, y, z) {
        return this.animation.transform && this.animation.transform().rotate(x, y, z);
    };
    WorldRenderObject.prototype.scale = function (x, y, z) {
        return this.animation.transform && this.animation.transform().scale(x, y, z);
    };
    WorldRenderObject.prototype.translate = function (x, y, z) {
        return this.animation.transform && this.animation.transform().translate(x, y, z);
    };
    WorldRenderObject.prototype.exists = function () {
        return this.loaded;
    };
    WorldRenderObject.getAllByStringID = function (stringID) {
        return WorldRenderObject.objects[stringID] || null;
    };
    WorldRenderObject.getAllByPositionAndStringID = function (stringID, x, y, z, roundFunc) {
        if (roundFunc === void 0) { roundFunc = Math.round; }
        var list = [];
        var group = this.getAllByStringID(stringID) || {};
        for (var i in group) {
            var object = group[i];
            var objX = roundFunc(object.x), objY = roundFunc(object.y), objZ = roundFunc(object.z);
            if (x == objX && y == objY && z == objZ) {
                list.push(object);
            }
        }
        return list;
    };
    WorldRenderObject.getAllByPosition = function (x, y, z, roundFunc) {
        if (roundFunc === void 0) { roundFunc = Math.round; }
        var list = [];
        for (var stringID in WorldRenderObject.objects) {
            list = list.concat(this.getAllByPositionAndStringID(stringID, x, y, z, roundFunc));
        }
        return list;
    };
    WorldRenderObject.onLevelLeft = function () {
        WorldRenderObject.objects = {};
    };
    WorldRenderObject.objects = {};
    __decorate([
        SubscribeEvent
    ], WorldRenderObject, "onLevelLeft", null);
    return WorldRenderObject;
}());
var RenderSide = /** @class */ (function () {
    function RenderSide(dir, model, importParams) {
        if (importParams === void 0) { importParams = null; }
        var _this = this;
        this.model = model;
        this.importParams = importParams;
        var rotations = [
            [0, -Math.PI, 0],
            [0, Math.PI, 0],
            [0, Math.PI / 2, 0],
            [0, -Math.PI / 2, 0]
            // [0, 0, 0],
            // [0, -Math.PI, 0],
            // [0, Math.PI / 2, 0],
            // [0, -Math.PI / 2, 0]
        ];
        if (model instanceof RenderMesh) {
            this.list = rotations.map(function (value) {
                var copy = model.clone();
                copy.rotate(value[0], value[1], value[2]);
                return copy;
            });
            return;
        }
        this.list = rotations.map(function (value) {
            return RenderHelper.generateMesh(dir, model, _this.importParams, value);
        });
    }
    RenderSide.prototype.getWithData = function (data) {
        return this.list[data];
    };
    RenderSide.prototype.getForTile = function (tileEntity) {
        var data = BlockSource.getCurrentClientRegion().getBlockData(tileEntity.x, tileEntity.y, tileEntity.z);
        return this.getWithData(data);
    };
    return RenderSide;
}());
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var BlockAnimation = /** @class */ (function () {
    function BlockAnimation(coords, tileEntity) {
        this.coords = coords;
        this.tileEntity = tileEntity;
        this.animation = new Animation.Base(coords.x, coords.y, coords.z);
        this.animation.setBlocklightMode();
        return;
    }
    BlockAnimation.prototype.load = function () {
        if (this.animation.exists()) {
            this.animation.destroy();
        }
        return this.animation.load();
    };
    BlockAnimation.prototype.describe = function (mesh, texture, scale, material) {
        if (scale === void 0) { scale = 1; }
        this.animation.describe(__assign({ mesh: mesh instanceof RenderSide ? mesh.getForTile(this.tileEntity) : mesh, skin: "terrain-atlas/" + texture + ".png", scale: scale }, (material && { material: material })));
    };
    BlockAnimation.prototype.rotate = function (x, y, z) {
        return this.animation.transform && this.animation.transform().rotate(x, y, z);
    };
    BlockAnimation.prototype.scale = function (x, y, z) {
        return this.animation.transform && this.animation.transform().scale(x, y, z);
    };
    BlockAnimation.prototype.setPos = function (x, y, z) {
        return this.animation.setPos(x, y, z);
    };
    BlockAnimation.prototype.refresh = function () {
        return this.animation.refresh();
    };
    BlockAnimation.prototype.destroy = function () {
        return this.animation.destroy();
    };
    return BlockAnimation;
}());
/**
 * Class to create android clickable field, which with click opens keyboard and inputs text.
 */
var Keyboard = /** @class */ (function () {
    function Keyboard(placeholderText) {
        this.placeholderText = placeholderText;
        this.context = UI.getContext();
    }
    Keyboard.prototype.getText = function (func) {
        this.func = func;
        return this;
    };
    Keyboard.prototype.open = function () {
        var self = this;
        this.context.runOnUiThread({
            run: function () {
                var editText = new android.widget.EditText(self.context);
                editText.setHint(self.placeholderText);
                var builder = new android.app.AlertDialog.Builder(self.context);
                builder.setView(editText).setPositiveButton("ok", {
                    onClick: function () {
                        var text = String(editText.getText());
                        self.func(text);
                    }
                }).show();
            }
        });
    };
    return Keyboard;
}());
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var UIHelper;
(function (UIHelper) {
    UIHelper.SCREEN_WIDTH = 1000;
    function separateText(text, line_size) {
        var e_1, _a;
        if (line_size === void 0) { line_size = 25; }
        var result = [];
        var line = "";
        try {
            for (var _b = __values(text.split(" ")), _c = _b.next(); !_c.done; _c = _b.next()) {
                var word = _c.value;
                if (line.length + word.length <= line_size) {
                    line += word + " ";
                }
                else {
                    result.push(line.trim());
                    line = word + " ";
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_1) throw e_1.error; }
        }
        if (line) {
            result.push(line.trim());
        }
        return result.join("\n");
    }
    UIHelper.separateText = separateText;
    function getItemIcon(itemID, x, y, size, bitmap) {
        if (size === void 0) { size = 70; }
        if (bitmap === void 0) { bitmap = "unknown"; }
        return {
            type: "slot",
            visual: true,
            source: new ItemStack(typeof Number(itemID) === "number" ? Number(itemID) : IDRegistry.parseID(itemID), 1),
            x: x,
            y: y,
            size: size,
            bitmap: bitmap
        };
    }
    UIHelper.getItemIcon = getItemIcon;
})(UIHelper || (UIHelper = {}));
var EScreenName;
(function (EScreenName) {
    EScreenName["IN_GAME_PLAY_SCREEN"] = "in_game_play_screen";
    EScreenName["WORLD_LOADING_PROGRESS_SCREEN"] = "world_loading_progress_screen";
    EScreenName["ENDER_CHEST_SCREEN"] = "ender_chest_screen";
    EScreenName["FURNACE_SCREEN"] = "furnace_screen";
    EScreenName["SMALL_CHEST_SCREEN"] = "small_chest_screen";
    EScreenName["CREATIVE_INVENTORY_SCREEN"] = "creative_inventory_screen";
    EScreenName["SURVIVAL_INVENTORY_SCREEN"] = "survival_inventory_screen";
    EScreenName["INVENTORY_SCREEN"] = "inventory_screen";
    EScreenName["INVENTORY_SCREEN_POCKET"] = "inventory_screen_pocket";
})(EScreenName || (EScreenName = {}));
Callback.addCallback("NativeGuiChanged", function (name, lastName, isPushEvent) {
    RuntimeData.local.screenName = name;
});
// namespace WorldSaves {
//     export const defaultData = {
//         players: {}
//     };
//     export let data = {
//         players: {}
//     } as { players: Record<number, typeof defaultData.players & Scriptable> } & Scriptable;
// };
// Callback.addCallback("ModsLoaded", () => {
//     for(const key in WorldSaves.defaultData) {
//         WorldSaves.data[key] = WorldSaves.defaultData[key];
//     };
// });
// Callback.addCallback("ServerPlayerLoaded", (player) => {
//     if(!(player in WorldSaves.data.players)) {
//         WorldSaves.data.players[player] = WorldSaves.defaultData.players;
//     };
//     const client = Network.getClientForPlayer(player);
//     if(client) {
//         client.send("packet.squid_core.set_player_data", {
//             uid: player,
//             data: WorldSaves.data.players[player]
//         });
//     };
//     for(const key in WorldSaves.defaultData) {
//         if(!(key in WorldSaves.data)) {
//             WorldSaves.data[key] = WorldSaves.defaultData[key];
//         };
//     };
// });
// Callback.addCallback("LevelLeft", () => {
//     for(const key in WorldSaves.defaultData) {
//         WorldSaves.data[key] = WorldSaves.defaultData[key];
//     };
// });
// Saver.addSavesScope("squid_core.world_saves", 
//     function read(scope: {data: typeof WorldSaves.data}) {
//         WorldSaves.data = scope && scope.data ? scope.data : WorldSaves.data;
//     },
//     function save() {
//         return { data: WorldSaves.data };
//     }
// );
// Network.addClientPacket("packet.squid_core.set_player_data", (data: {uid: number, data: typeof WorldSaves.defaultData.players}) => {
//     WorldSaves.data = WorldSaves.data || {
//         players: {}
//     };
//     WorldSaves.data[data.uid] = data.data;
// });
var Vector3 = /** @class */ (function () {
    function Vector3(x, y, z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    ;
    Vector3.prototype.copy = function () {
        return new Vector3(this.x, this.y, this.z);
    };
    Vector3.prototype.equals = function (vector) {
        return this.x === vector.x && this.y === vector.y && this.z === vector.z;
    };
    Vector3.prototype.add = function (vector) {
        return new Vector3(this.x + vector.x, this.y + vector.y, this.z + vector.z);
    };
    Vector3.prototype.subtract = function (vector) {
        return new Vector3(this.x - vector.x, this.y - vector.y, this.z - vector.z);
    };
    Vector3.prototype.multiply = function (scalar) {
        return new Vector3(this.x * scalar, this.y * scalar, this.z * scalar);
    };
    Vector3.prototype.divide = function (scalar) {
        return new Vector3(this.x / scalar, this.y / scalar, this.z / scalar);
    };
    Vector3.prototype.dot = function (vector) {
        return this.x * vector.x + this.y * vector.y + this.z * vector.z;
    };
    Vector3.prototype.cross = function (vector) {
        return new Vector3(this.y * vector.z - this.z * vector.y, this.z * vector.x - this.x * vector.z, this.x * vector.y - this.y * vector.x);
    };
    Vector3.prototype.length = function () {
        return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
    };
    Vector3.prototype.normalize = function () {
        var length = this.length();
        return new Vector3(this.x / length, this.y / length, this.z / length);
    };
    Vector3.DOWN = new Vector3(0, -1, 0);
    Vector3.UP = new Vector3(0, 1, 0);
    Vector3.NORTH = new Vector3(0, 0, -1);
    Vector3.SOUTH = new Vector3(0, 0, 1);
    Vector3.EAST = new Vector3(-1, 0, 0);
    Vector3.WEST = new Vector3(1, 0, 0);
    return Vector3;
}());
var ItemStack = /** @class */ (function () {
    function ItemStack(id, count, data, extra) {
        if (typeof id == "object") {
            this.id = id.id;
            this.count = id.count || (id ? this.getMaxStack() : 0);
            this.data = id.data || 0;
            this.extra = id.extra;
        }
        else {
            this.id = id || 0;
            this.count = count || (id ? this.getMaxStack() : 0);
            this.data = data || 0;
            this.extra = extra;
        }
    }
    ItemStack.prototype.decrease = function (count) {
        if (count === void 0) { count = 1; }
        this.count = Math.max(this.count - count, 0);
    };
    ItemStack.prototype.increase = function (count) {
        if (count === void 0) { count = 1; }
        this.count = Math.min(this.count + count, this.getMaxStack());
    };
    ItemStack.prototype.equals = function (stack) {
        return (stack.id == this.id &&
            this.count == stack.count &&
            stack.data == this.data);
    };
    ItemStack.prototype.getItemInstance = function () {
        return {
            id: this.id,
            count: this.count,
            data: this.data,
            extra: this.extra
        };
    };
    ItemStack.prototype.isEmpty = function () {
        return this.id == 0 && this.count == 0 && this.data == 0 && this.extra == null;
    };
    ItemStack.prototype.clear = function () {
        this.id = 0;
        this.count = 0;
        delete this.data;
        delete this.extra;
    };
    ItemStack.prototype.getMaxStack = function () {
        return Item.getMaxStack(this.id);
    };
    ItemStack.prototype.getMaxDamage = function () {
        return Item.getMaxDamage(this.id);
    };
    ItemStack.prototype.isNativeItem = function () {
        return Item.isNativeItem(this.id);
    };
    ItemStack.prototype.getStringID = function () {
        return IDRegistry.getStringIdForItemId(this.id);
    };
    ItemStack.prototype.copy = function () {
        return new ItemStack(this.id, this.count, this.data, this.extra);
    };
    ItemStack.equals = function (stack1, stack2) {
        return (stack1.id == stack2.id &&
            stack1.count == stack2.count &&
            stack1.data == stack2.data //&& 
        //((stack1.extra && stack2.extra) && stack1.extra.equals(stack2.extra))
        );
    };
    ItemStack.contains = function (stack1, stack2) {
        return (stack1.id == stack2.id &&
            stack1.count >= (stack2.count || 1) &&
            (stack1.data || 0) == (stack2.data || 0) //&& 
        //((stack1.extra && stack2.extra) && stack1.extra.equals(stack2.extra))
        );
    };
    return ItemStack;
}());
var BasicItem = /** @class */ (function () {
    function BasicItem(stringID, texture, params) {
        if (params === void 0) { params = {}; }
        this.maxStack = 64;
        this.id = IDRegistry.genItemID(stringID);
        this.stringID = stringID;
        this.maxStack = params.stack || 64;
        this.texture = texture;
        if ("getFood" in this) {
            params.food = this.getFood();
        }
        this.create(params || {});
    }
    BasicItem.prototype.getMaxStack = function () {
        return this.maxStack;
    };
    BasicItem.prototype.getName = function () {
        return "item.".concat(this.stringID);
    };
    BasicItem.prototype.getStringID = function () {
        return this.stringID;
    };
    BasicItem.prototype.getID = function () {
        return this.id;
    };
    BasicItem.prototype.getItemCategory = function () {
        return EItemCategory.ITEMS;
    };
    BasicItem.prototype.getTexture = function () {
        return this.texture;
    };
    BasicItem.prototype.inCreative = function () {
        return true;
    };
    BasicItem.prototype.getTags = function () {
        return null;
    };
    BasicItem.setFunctions = function (instance) {
        if ("isFireResistant" in instance) {
            Item.setFireResistant(instance.id, true);
        }
        if ("isExplodable" in instance) {
            Item.setExplodable(instance.id, true);
        }
        if ("isShouldDespawn" in instance) {
            Item.setShouldDespawn(instance.id, true);
        }
        if ("isGlint" in instance) {
            Item.setGlint(instance.id, true);
        }
        if ('onIconOverride' in instance) {
            Item.registerIconOverrideFunction(instance.id, instance.onIconOverride.bind(this));
        }
        if ('onNoTargetUse' in instance) {
            Item.registerNoTargetUseFunction(instance.id, function (item, player) { return instance.onNoTargetUse(new ItemStack(item), player); });
        }
        if ('onUsingReleased' in instance) {
            Item.registerUsingReleasedFunction(instance.id, function (item, ticks, player) { return instance.onUsingReleased(new ItemStack(item), ticks, player); });
        }
        if ('onUsingComplete' in instance) {
            Item.registerUsingCompleteFunction(instance.id, function (item, player) { return instance.onUsingComplete(new ItemStack(item), player); });
        }
        if ('onItemUse' in instance) {
            Item.registerUseFunction(instance.id, function (coords, item, block, player) { return instance.onItemUse(coords, new ItemStack(item), block, player); });
        }
        if ('onNameOverride' in instance) {
            Item.registerNameOverrideFunction(instance.id, instance.onNameOverride.bind(this));
        }
        if ('onItemHold' in instance) {
            Item.registerHoldFunctionForID(instance.id, function (item, playerUid, slotIndex) { return instance.onItemHold(item, playerUid, slotIndex); });
        }
        if ("getItemCategory" in instance) {
            Item.setCategory(instance.id, instance.getItemCategory());
        }
    };
    BasicItem.prototype.create = function (params) {
        if (params === void 0) { params = {}; }
        var tags = this.getTags();
        var itemParams = Object.assign({
            stack: this.getMaxStack(),
            isTech: !this.inCreative(),
            category: this.getItemCategory()
        }, params);
        var key = "createItem";
        if (tags != null) {
            TagRegistry.addCommonObject("items", this.id, tags);
        }
        if ("food" in params) {
            key = "createFoodItem";
        }
        if ("type" in params) {
            key = "createArmorItem";
        }
        if ("isThrowable" in this && this.isThrowable() == true) {
            key = "createThrowableItem";
        }
        Item[key](this.stringID, this.getName(), this.getTexture(), itemParams);
        BasicItem.setFunctions(this);
    };
    return BasicItem;
}());
var a = 1; //hello 
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var LiquidStorageItem = /** @class */ (function (_super) {
    __extends(LiquidStorageItem, _super);
    function LiquidStorageItem(stringID, texture, params, data) {
        if (data === void 0) { data = 0; }
        var _this = _super.call(this, stringID, texture, params) || this;
        LiquidItemRegistry.registerLiquidStorage(_this.id, data, params);
        return _this;
    }
    return LiquidStorageItem;
}(BasicItem));
var EDestroyLevel;
(function (EDestroyLevel) {
    EDestroyLevel[EDestroyLevel["HAND"] = 0] = "HAND";
    EDestroyLevel[EDestroyLevel["STONE"] = 1] = "STONE";
    EDestroyLevel[EDestroyLevel["IRON"] = 2] = "IRON";
    EDestroyLevel[EDestroyLevel["DIAMOND"] = 3] = "DIAMOND";
    EDestroyLevel[EDestroyLevel["OBSIDIAN"] = 4] = "OBSIDIAN";
})(EDestroyLevel || (EDestroyLevel = {}));
var BlockModel = /** @class */ (function () {
    function BlockModel(dir, model, texture, data) {
        if (texture === void 0) { texture = model; }
        if (data === void 0) { data = -1; }
        texture = typeof texture == "object" ? texture : { name: texture, meta: 0 };
        this.mesh = new RenderMesh();
        this.mesh.importFromFile(dir + model + ".obj", "obj", null);
        this.mesh.setBlockTexture(texture.name, texture.meta);
        this.mesh.translate(0.5, 0, 0.5);
        this.data = data;
    }
    BlockModel.prototype.getRenderMesh = function () {
        return this.mesh;
    };
    BlockModel.prototype.scale = function (x, y, z) {
        this.mesh.scale(x, y, z);
        return this;
    };
    BlockModel.prototype.translate = function (x, y, z) {
        this.mesh.translate(x, y, z);
        return this;
    };
    BlockModel.prototype.rotate = function (x, y, z) {
        this.mesh.rotate(x, y, z);
        return this;
    };
    BlockModel.prototype.getBlockData = function () {
        return this.data;
    };
    return BlockModel;
}());
var BasicBlock = /** @class */ (function () {
    function BasicBlock(stringID, variationList) {
        this.id = IDRegistry.genBlockID(stringID);
        this.stringID = stringID;
        this.variationList = variationList || [{
                inCreative: true,
                name: "block.".concat(stringID),
                texture: [[stringID, 0]]
            }];
        BasicBlock.build(this);
    }
    /**
     * Method declares, can block place rotated by data or not
     */
    BasicBlock.prototype.canRotate = function () {
        return false;
    };
    /**
     * Method must list of blockstates which will be registered to block
     */
    BasicBlock.prototype.getStates = function () {
        return null;
    };
    /**
     * Method must return tags which will be added to block
     */
    BasicBlock.prototype.getTags = function () {
        return null;
    };
    BasicBlock.prototype.getDestroyLevel = function () {
        return EDestroyLevel.STONE;
    };
    BasicBlock.setStates = function (id, states) {
        for (var i in states) {
            var state = states[i];
            if (typeof state == "string") {
                Block.addBlockState && Block.addBlockState(id, state);
            }
            else {
                Block.addBlockStateId && Block.addBlockStateId(id, state);
            }
        }
    };
    BasicBlock.setModel = function (id, data, model) {
        var render = null;
        var mesh = null;
        var blockModel = null;
        if (model instanceof ICRender.Model) {
            render = model;
        }
        else {
            if (model instanceof BlockRenderer.Model) {
                blockModel = model;
            }
            else {
                render = new ICRender.Model();
                if (model instanceof BlockModel) {
                    mesh = model.getRenderMesh();
                    data = model.getBlockData();
                }
                else {
                    mesh = model;
                }
                blockModel = new BlockRenderer.Model(mesh);
            }
            render.addEntry(blockModel);
        }
        BlockRenderer.setStaticICRender(id, data || -1, render);
    };
    BasicBlock.build = function (blockPrototype) {
        if (blockPrototype.canRotate() == true) {
            blockPrototype.variationList.map(function (v) {
                if (v.texture.length < 6) {
                    for (var i = v.texture.length; i < 6; i++) {
                        v.texture.push(v.texture[v.texture.length - 1]);
                    }
                }
                return v;
            });
            Block.createBlockWithRotation(blockPrototype.stringID, blockPrototype.variationList);
        }
        else {
            Block.createBlock(blockPrototype.stringID, blockPrototype.variationList);
        }
        var tags = blockPrototype.getTags();
        if (tags != null) {
            TagRegistry.addCommonObject("blocks", blockPrototype.id, tags);
        }
        var states = blockPrototype.getStates();
        if (states != null) {
            BasicBlock.setStates(blockPrototype.id, states);
        }
        if ("getModel" in blockPrototype) {
            var modelList = [].concat(blockPrototype.getModel());
            if (modelList.length == 1) {
                BasicBlock.setModel(blockPrototype.id, -1, modelList[0]);
            }
            else {
                for (var i = 0; i < modelList.length; i++) {
                    var model = modelList[i];
                    var data = model instanceof BlockModel ? model.getBlockData() : i;
                    BasicBlock.setModel(blockPrototype.id, data, model);
                }
            }
        }
        if ("getDestroyTime" in blockPrototype) {
            Block.setDestroyTime(blockPrototype.id, blockPrototype.getDestroyTime());
        }
        if ("getSoundType" in blockPrototype) {
            Block.setSoundType(blockPrototype.id, blockPrototype.getSoundType());
        }
        if ("getFriction" in blockPrototype) {
            Block.setFriction(blockPrototype.id, blockPrototype.getFriction());
        }
        if ("getLightLevel" in blockPrototype) {
            Block.setLightLevel(blockPrototype.id, blockPrototype.getLightLevel());
        }
        if ("getLightOpacity" in blockPrototype) {
            Block.setLightOpacity(blockPrototype.id, blockPrototype.getLightOpacity());
        }
        if ("getExplosionResistance" in blockPrototype) {
            Block.setExplosionResistance(blockPrototype.id, blockPrototype.getExplosionResistance());
        }
        if ("getMapColor" in blockPrototype) {
            Block.setMapColor(blockPrototype.id, blockPrototype.getMapColor());
        }
        if ("getMaterial" in blockPrototype) {
            ToolAPI.registerBlockMaterial(blockPrototype.id, blockPrototype.getMaterial(), blockPrototype.getDestroyLevel());
        }
        if ("getRenderLayer" in blockPrototype) {
            Block.setRenderLayer(blockPrototype.id, blockPrototype.getRenderLayer());
        }
        if ("getTranslucency" in blockPrototype) {
            Block.setTranslucency(blockPrototype.id, blockPrototype.getTranslucency());
        }
        if ("isSolid" in blockPrototype) {
            Block.setSolid(blockPrototype.id, blockPrototype.isSolid());
        }
        if ("getRenderType" in blockPrototype) {
            Block.setRenderType(blockPrototype.id, blockPrototype.getRenderType());
        }
        if ("getTileEntity" in blockPrototype) {
            TileEntity.registerPrototype(blockPrototype.id, blockPrototype.getTileEntity());
        }
        if ("getCreativeGroup" in blockPrototype) {
            var group = blockPrototype.getCreativeGroup();
            Item.addCreativeGroup(group, group, [blockPrototype.id]);
        }
        if ("getDrop" in blockPrototype) {
            Block.registerDropFunctionForID(blockPrototype.id, function (coords, id, data, diggingLevel, enchant, item, region) {
                return blockPrototype.getDrop(coords, id, data, diggingLevel, enchant, new ItemStack(item), region);
            });
        }
        if ("onDestroy" in blockPrototype) {
            Block.registerDestroyFunctionForID(blockPrototype.id, blockPrototype.onDestroy.bind(blockPrototype));
        }
        if ("onDestroyContinue" in blockPrototype) {
            Block.registerDestroyContinueFunctionForID(blockPrototype.id, blockPrototype.onDestroyContinue.bind(blockPrototype));
        }
        if ("onDestroyStart" in blockPrototype) {
            Block.registerDestroyStartFunctionForID(blockPrototype.id, blockPrototype.onDestroyStart.bind(blockPrototype));
        }
        if ("onPlace" in blockPrototype) {
            Block.registerPlaceFunctionForID(blockPrototype.id, function (coords, item, block, player, region) {
                return blockPrototype.onPlace(coords, new ItemStack(item), block, player, region);
            });
        }
        if ("onNeighbourChange" in blockPrototype) {
            Block.registerNeighbourChangeFunctionForID(blockPrototype.id, function (coords, block, changedCoords, region) {
                return blockPrototype.onNeighbourChange(coords, block, changedCoords, region);
            });
        }
        if ("onEntityInside" in blockPrototype) {
            Block.registerEntityInsideFunctionForID(blockPrototype.id, function (coords, block, entity) {
                return blockPrototype.onEntityInside(coords, block, entity);
            });
        }
        if ("onEntityStepOn" in blockPrototype) {
            Block.registerEntityStepOnFunctionForID(blockPrototype.id, function (coords, block, entity) {
                return blockPrototype.onEntityStepOn(coords, block, entity);
            });
        }
        if ("onRandomTick" in blockPrototype) {
            Block.setRandomTickCallback(blockPrototype.id, function (x, y, z, id, data, region) {
                return blockPrototype.onRandomTick(x, y, z, id, data, region);
            });
        }
        if ("onClick" in blockPrototype) {
            Block.registerClickFunctionForID(blockPrototype.id, function (coords, item, block, player) {
                return blockPrototype.onClick(coords, new ItemStack(item), block, player);
            });
        }
        if ("onProjectileHit" in blockPrototype) {
            Block.registerProjectileHitFunction(blockPrototype.id, blockPrototype.onProjectileHit.bind(blockPrototype));
        }
        if ("onSelection" in blockPrototype) {
            Block.registerSelectionFunctionForID(blockPrototype.id, blockPrototype.onSelection.bind(blockPrototype));
        }
        BasicItem.setFunctions(blockPrototype);
        Block.setDestroyLevel(blockPrototype.stringID, blockPrototype.getDestroyLevel());
    };
    return BasicBlock;
}());
var BlockPlant = /** @class */ (function (_super) {
    __extends(BlockPlant, _super);
    function BlockPlant(stringID, variationList) {
        var _this = _super.call(this, stringID, variationList) || this;
        Block.setEmptyCollisionShape(_this.id);
        return _this;
    }
    BlockPlant.prototype.getCreativeGroup = function () {
        return "nature";
    };
    BlockPlant.prototype.onNeighbourChange = function (coords, block, changedCoords, region) {
        var bottomBlock = region.getBlockID(coords.x, coords.y - 1, coords.z);
        if (!BlockPlant.allowedBlockList.includes(bottomBlock)) {
            return region.destroyBlock(coords.x, coords.y, coords.z, true);
        }
    };
    BlockPlant.prototype.onPlace = function (coords, item, block, player, region) {
        var upperBlock = region.getBlockID(coords.x, coords.y + 1, coords.z);
        var isAllowedBlock = BlockPlant.allowedBlockList.includes(block.id);
        if (isAllowedBlock && upperBlock === 0) {
            return region.setBlock(coords.x, coords.y + 1, coords.z, this.id, 0);
        }
    };
    BlockPlant.prototype.isSolid = function () {
        return false;
    };
    BlockPlant.prototype.getLightOpacity = function () {
        return 0;
    };
    BlockPlant.prototype.getDestroyTime = function () {
        return 0;
    };
    BlockPlant.prototype.getSoundType = function () {
        return "grass";
    };
    BlockPlant.prototype.getRenderType = function () {
        return 1;
    };
    BlockPlant.allowedBlockList = [
        VanillaBlockID.dirt,
        VanillaBlockID.grass,
        VanillaBlockID.grass_path,
        VanillaBlockID.podzol,
        VanillaBlockID.mycelium
    ];
    return BlockPlant;
}(BasicBlock));
var BlockBush = /** @class */ (function (_super) {
    __extends(BlockBush, _super);
    function BlockBush(stringID, variationList, berryID) {
        var _this = _super.call(this, stringID, variationList) || this;
        _this.berryID = berryID;
        return _this;
    }
    BlockBush.prototype.getMaxStage = function () {
        return this.variationList.length - 1;
    };
    BlockBush.prototype.onRandomTick = function (x, y, z, id, data, region) {
        if (Math.random() > this.getChance())
            return;
        if (data < this.getMaxStage()) {
            region.setBlock(x, y, z, id, data + 1);
        }
    };
    BlockBush.prototype.onClick = function (coords, item, block, player) {
        if (block.data === this.getMaxStage()) {
            var count = this.getCount();
            BlockSource.getDefaultForActor(player).spawnDroppedItem(coords.x + 0.5, coords.y + 0.7, coords.z + 0.5, this.berryID, MathHelper.randomNumber(count[0], count[1]), 0);
        }
    };
    return BlockBush;
}(BlockPlant));
var RotatableLog = /** @class */ (function (_super) {
    __extends(RotatableLog, _super);
    function RotatableLog(id, texture) {
        texture = texture || id;
        var upperTexture = texture + "_top";
        var sideTexture = texture + "_side";
        return _super.call(this, id, [{
                inCreative: true,
                name: "block.infinite_forest." + id,
                texture: [
                    [upperTexture, 0],
                    [upperTexture, 0],
                    [sideTexture, 0]
                ]
            },
            {
                texture: [
                    [sideTexture, 0],
                    [sideTexture, 0],
                    [upperTexture, 0],
                    [upperTexture, 0],
                    [sideTexture, 0]
                ]
            },
            {
                texture: [
                    [sideTexture, 0],
                    [sideTexture, 0],
                    [sideTexture, 0],
                    [sideTexture, 0],
                    [upperTexture, 0]
                ]
            }]) || this;
    }
    ;
    RotatableLog.prototype.onPlace = function (coords, item, block, player, region) {
        var data = 0;
        switch (coords.side) {
            case 5:
                data = 2;
                break;
            case 4:
                data = 2;
                break;
            case 3:
                data = 1;
                break;
            case 2:
                data = 1;
                break;
        }
        region.setBlock(coords.relative.x, coords.relative.y, coords.relative.z, this.id, data);
    };
    RotatableLog.prototype.getSoundType = function () {
        return "wood";
    };
    RotatableLog.prototype.getDrop = function (coords, id, data, diggingLevel, enchant, item, region) {
        return [[id, 1, 0]];
    };
    return RotatableLog;
}(BasicBlock));
var Log = /** @class */ (function (_super) {
    __extends(Log, _super);
    function Log(id, hewn_id) {
        var _this = _super.call(this, id) || this;
        _this.hewn_id = hewn_id;
        return _this;
    }
    Log.prototype.onClick = function (coords, item, block, player) {
        var _a, _b;
        if ((_b = (_a = ToolAPI.getToolData(item.id)) === null || _a === void 0 ? void 0 : _a.blockMaterials) === null || _b === void 0 ? void 0 : _b["wood"]) {
            BlockSource.getDefaultForActor(player).setBlock(coords.x, coords.y, coords.z, BlockID[this.hewn_id], block.data);
        }
    };
    return Log;
}(RotatableLog));
var Bark = /** @class */ (function (_super) {
    __extends(Bark, _super);
    function Bark(id, texture) {
        return _super.call(this, id, texture) || this;
    }
    return Bark;
}(RotatableLog));
var Hewn = /** @class */ (function (_super) {
    __extends(Hewn, _super);
    function Hewn(id) {
        return _super.call(this, id) || this;
    }
    return Hewn;
}(RotatableLog));
var Planks = /** @class */ (function (_super) {
    __extends(Planks, _super);
    function Planks(id, log_id, bark_id, hewn_id) {
        var _this = _super.call(this, id, [{
                name: "block.infinite_forest." + id,
                inCreative: true,
                texture: [[id, 0]]
            }]) || this;
        _this.log_id = log_id;
        _this.bark_id = bark_id;
        _this.hewn_id = hewn_id;
        return _this;
    }
    return Planks;
}(BasicBlock));
/**
 * Decorator to create network event with your method in tile entity.
 * @param target Your tile entity
 * @param propertyName Name of method
 */
function NetworkEvent(target, propertyName) {
    target.eventNames = __assign({}, target.eventNames);
    target.eventNames.network = target.eventNames.network || [];
    target.eventNames.network.push(propertyName);
}
/**
 * Decorator to create container event with your method in tile entity.
 * @param target Your tile entity
 * @param propertyName Name of method
 */
function ContainerEvent(target, propertyName) {
    target.eventNames = __assign({}, target.eventNames);
    target.eventNames.container = target.eventNames.container || [];
    target.eventNames.container.push(propertyName);
}
;
var LocalTileEntity = /** @class */ (function () {
    function LocalTileEntity() {
        if ("onTick" in this) {
            this.tick = this.onTick;
        }
        if ("onSelection" in this) {
            this.selection = this.onSelection;
        }
        this.load = this.onLoad;
        this.unload = this.onUnload;
        TileEntity.buildEvents(this);
    }
    /**@deprecated
     * Use {@link onLoad} instead
     */
    LocalTileEntity.prototype.load = function () { };
    ;
    /**@deprecated
     * Use {@link onUnload} instead
     */
    LocalTileEntity.prototype.unload = function () { };
    ;
    LocalTileEntity.prototype.onLoad = function () { };
    ;
    LocalTileEntity.prototype.onUnload = function () { };
    ;
    return LocalTileEntity;
}());
/**Class to create tile entities in separated client server side formats.
 * @example
 * ```ts
 * class LocalExampleTile extends LocalTileEntity {
 *     \@NetworkEvent
 *     public exampleMessagePacket(): void {
 *         Game.message("example");
 *         return;
 *     }
 *
 *     public onTick(): void {
 *         Game.message("tick work")
 *     }
 * }
 *
 * class ExampleTile extends CommonTileEntity {
 *     public getLocalTileEntity(): LocalTileEntity {
 *         return new LocalExampleTile();
 *     }
 *
 *     public onTick(): void {
 *         this.sendPacket("exampleMessagePacket", {});
 *     }
 * }
 *
 * class ExampleBlock extends BasicBlock {
 *     public constructor() {
 *         super("example_block");
 *     }
 *
 *     public override getTileEntity(): CommonTileEntity {
 *         return new ExampleTile();
 *     }
 * }
 * ```
 */
var CommonTileEntity = /** @class */ (function () {
    function CommonTileEntity() {
        this.useNetworkItemContainer = true;
        var localTileEntity = this.getLocalTileEntity();
        if (localTileEntity != null) {
            this.client = localTileEntity;
        }
        if ("onTick" in this) {
            this.tick = this.onTick;
        }
        this.init = this.onInit;
        this.load = this.onLoad;
        this.unload = this.onUnload;
        this.destroyBlock = this.onDestroyBlock;
        this.destroy = this.onDestroyTile;
        this.projectileHit = this.onProjectileHit;
        TileEntity.buildEvents(this);
        if ("data" in this) {
            this.defaultValues = Object.assign({}, this.defaultValues, this.data);
        }
    }
    CommonTileEntity.prototype.created = function () { };
    ;
    /**@deprecated
     * Use {@link onInit} instead
     */
    CommonTileEntity.prototype.init = function () { };
    ;
    /**@deprecated
     * Use {@link onLoad} instead
     */
    CommonTileEntity.prototype.load = function () { };
    ;
    /**@deprecated
     * Use {@link onUnload} instead
     */
    CommonTileEntity.prototype.unload = function () { };
    ;
    CommonTileEntity.prototype.onCheckerTick = function (isInitialized, isLoaded, wasLoaded) { };
    ;
    CommonTileEntity.prototype.click = function (id, count, data, coords, player, extra) { };
    ;
    /**@deprecated
     * Use {@link onDestroyBlock} instead
     */
    CommonTileEntity.prototype.destroyBlock = function (coords, player) { };
    ;
    CommonTileEntity.prototype.redstone = function (params) { };
    ;
    /**@deprecated
     * Use {@link onProjectileHit} instead
     */
    CommonTileEntity.prototype.projectileHit = function (coords, target) { };
    ;
    /**@deprecated
     * Use {@link onDestroyTile} instead
     */
    CommonTileEntity.prototype.destroy = function () { };
    ;
    CommonTileEntity.prototype.onInit = function () { };
    ;
    CommonTileEntity.prototype.onLoad = function () { };
    ;
    CommonTileEntity.prototype.onUnload = function () { };
    ;
    /**
     * Method, calls when player clicks on block with this tile entity. If method returns false, ui will be opened.
     * @param coords
     * @param item
     * @param player
     * @returns boolean
     */
    CommonTileEntity.prototype.onClick = function (coords, item, player) {
        return false;
    };
    CommonTileEntity.prototype.onDestroyBlock = function (coords, player) { };
    ;
    CommonTileEntity.prototype.onProjectileHit = function (coords, target) { };
    ;
    CommonTileEntity.prototype.onDestroyTile = function () { };
    ;
    CommonTileEntity.prototype.getGuiScreen = function () {
        return null;
    };
    CommonTileEntity.prototype.getScreenByName = function (screenName, container) {
        return null;
    };
    CommonTileEntity.prototype.getScreenName = function (player, coords) {
        return "main";
    };
    CommonTileEntity.prototype.preventUI = function (id, count, data, coords, player, extra) {
        return Entity.getSneaking(player);
    };
    CommonTileEntity.prototype.onItemClick = function (id, count, data, coords, player, extra) {
        if (!this.onClick(coords, new ItemStack(id, count, data, extra), player)) {
            if (!this.preventUI(id, count, data, coords, player, extra)) {
                var client = Network.getClientForPlayer(player);
                if (client != null) {
                    var screenName = this.getScreenName(player, coords);
                    if (screenName && this.getScreenByName(screenName, this.container)) {
                        this.container.openFor(client, screenName);
                        return true;
                    }
                }
            }
        }
        return false;
    };
    CommonTileEntity.prototype.requireMoreLiquid = function (liquid, amount) { };
    ;
    CommonTileEntity.prototype.selfDestroy = function () {
        TileEntity.destroyTileEntityAtCoords(this.x, this.y, this.z);
    };
    CommonTileEntity.prototype.getLocalTileEntity = function () {
        return null;
    };
    return CommonTileEntity;
}());
var PlayerUser = /** @class */ (function () {
    function PlayerUser(playerUid) {
        this.playerUid = playerUid;
        this.actor = new PlayerActor(playerUid);
    }
    PlayerUser.prototype.getUid = function () {
        return this.actor.getUid();
    };
    PlayerUser.prototype.getDimension = function () {
        return this.actor.getDimension();
    };
    PlayerUser.prototype.getGameMode = function () {
        return this.actor.getGameMode();
    };
    PlayerUser.prototype.addItemToInventory = function (item, count, data, extra) {
        if (typeof item === "object") {
            this.actor.addItemToInventory(item.id, item.count, item.data, item.extra, true);
        }
        else {
            this.actor.addItemToInventory(item, count || Item.getMaxStack(item), data || 0, extra, true);
        }
    };
    PlayerUser.prototype.getInventorySlot = function (slot) {
        return new ItemStack(this.actor.getInventorySlot(slot));
    };
    PlayerUser.prototype.setInventorySlot = function (slot, item, count, data, extra) {
        if (typeof item === "object") {
            this.actor.setInventorySlot(slot, item.id, item.count, item.data, item.extra);
        }
        else {
            this.actor.setInventorySlot(slot, item, count || Item.getMaxStack(item), data || 0, extra);
        }
    };
    PlayerUser.prototype.getArmor = function (slot) {
        return new ItemStack(this.actor.getArmor(slot));
    };
    PlayerUser.prototype.setArmor = function (slot, item, count, data, extra) {
        if (typeof item === "object") {
            this.actor.setArmor(slot, item.id, item.count, item.data, item.extra);
        }
        else {
            this.actor.setArmor(slot, item, count || Item.getMaxStack(item), data || 0, extra);
        }
    };
    PlayerUser.prototype.setRespawnCoords = function (x, y, z) {
        if (typeof x === "object") {
            this.actor.setRespawnCoords(x.x, x.y, x.z);
        }
        else {
            this.actor.setRespawnCoords(x, y, z);
        }
    };
    PlayerUser.prototype.spawnExpOrbs = function (x, y, z, value) {
        if (typeof x === "object") {
            this.actor.spawnExpOrbs(x.x, x.y, x.z, value);
        }
        else {
            this.actor.spawnExpOrbs(x, y, z, value);
        }
    };
    PlayerUser.prototype.getPointer = function () {
        return this.actor.getPointer();
    };
    PlayerUser.prototype.isValid = function () {
        return this.actor.isValid();
    };
    PlayerUser.prototype.getSelectedSlot = function () {
        return this.actor.getSelectedSlot();
    };
    PlayerUser.prototype.setSelectedSlot = function (slot) {
        this.actor.setSelectedSlot(slot);
    };
    PlayerUser.prototype.getExperience = function () {
        return this.actor.getExperience();
    };
    PlayerUser.prototype.setExperience = function (exp) {
        this.actor.setExperience(exp);
    };
    PlayerUser.prototype.addExperience = function (amount) {
        this.actor.addExperience(amount);
    };
    PlayerUser.prototype.getLevel = function () {
        return this.actor.getLevel();
    };
    PlayerUser.prototype.setLevel = function (level) {
        this.actor.setLevel(level);
    };
    PlayerUser.prototype.getExhaustion = function () {
        return this.actor.getExhaustion();
    };
    PlayerUser.prototype.setExhaustion = function (value) {
        this.actor.setExhaustion(value);
    };
    PlayerUser.prototype.getHunger = function () {
        return this.actor.getHunger();
    };
    PlayerUser.prototype.setHunger = function (value) {
        this.actor.setHunger(value);
    };
    PlayerUser.prototype.getSaturation = function () {
        return this.actor.getSaturation();
    };
    PlayerUser.prototype.setSaturation = function (value) {
        this.actor.setSaturation(value);
    };
    PlayerUser.prototype.getScore = function () {
        return this.actor.getScore();
    };
    PlayerUser.prototype.setScore = function (value) {
        this.actor.setScore(value);
    };
    PlayerUser.prototype.getItemUseDuration = function () {
        return this.actor.getItemUseDuration();
    };
    PlayerUser.prototype.getItemUseIntervalProgress = function () {
        return this.actor.getItemUseIntervalProgress();
    };
    PlayerUser.prototype.getItemUseStartupProgress = function () {
        return this.actor.getItemUseStartupProgress();
    };
    PlayerUser.prototype.isOperator = function () {
        return this.actor.isOperator();
    };
    PlayerUser.prototype.setPlayerBooleanAbility = function (ability, value) {
        this.actor.setPlayerBooleanAbility(ability, value);
    };
    PlayerUser.prototype.setPlayerFloatAbility = function (ability, value) {
        this.actor.setPlayerFloatAbility(ability, value);
    };
    PlayerUser.prototype.getPlayerBooleanAbility = function (ability) {
        return this.actor.getPlayerBooleanAbility(ability);
    };
    PlayerUser.prototype.getPlayerFloatAbility = function (ability) {
        return this.actor.getPlayerFloatAbility(ability);
    };
    PlayerUser.prototype.canFly = function () {
        return this.actor.canFly();
    };
    PlayerUser.prototype.setCanFly = function (enabled) {
        this.actor.setCanFly(enabled);
    };
    PlayerUser.prototype.isFlying = function () {
        return this.actor.isFlying();
    };
    PlayerUser.prototype.setFlying = function (enabled) {
        return this.actor.setFlying(enabled);
    };
    PlayerUser.prototype.getEffect = function (effect) {
        return Entity.getEffect(this.playerUid, effect);
    };
    PlayerUser.prototype.setEffect = function (effectId, effectData, effectTime, ambience, particles) {
        Entity.addEffect(this.playerUid, effectId, effectData, effectTime, ambience, particles);
    };
    PlayerUser.prototype.isSneaking = function () {
        return Entity.getSneaking(this.playerUid);
    };
    PlayerUser.prototype.setSneaking = function (value) {
        Entity.setSneaking(this.playerUid, value);
    };
    PlayerUser.prototype.getName = function () {
        return Entity.getNameTag(this.playerUid);
    };
    PlayerUser.prototype.getCarriedItem = function () {
        return new ItemStack(Entity.getCarriedItem(this.playerUid));
    };
    PlayerUser.prototype.decreaseCarriedItem = function (count) {
        if (count === void 0) { count = 1; }
        var stack = this.getCarriedItem();
        Entity.setCarriedItem(this.playerUid, stack.id, stack.count - count, stack.data, stack.extra);
    };
    PlayerUser.prototype.clearSlot = function (slot) {
        this.setInventorySlot(typeof slot === "number" ? slot : this.getSelectedSlot(), new ItemStack());
    };
    PlayerUser.prototype.clearInventory = function () {
        for (var i = 0; i < 36; i++) {
            this.setInventorySlot(i, new ItemStack());
        }
    };
    PlayerUser.prototype.getSelectedItem = function () {
        return this.getInventorySlot(this.getSelectedSlot());
    };
    PlayerUser.isCreative = function (player) {
        var gamemode = new PlayerActor(player).getGameMode();
        return gamemode === EGameMode.CREATIVE || gamemode === EGameMode.SPECTATOR;
    };
    return PlayerUser;
}());
var BasicDimension = /** @class */ (function () {
    function BasicDimension(id, stringId, biome) {
        this.id = id;
        this.stringId = stringId;
        this.layers = [];
        this.dimension = new Dimensions.CustomDimension(stringId, id);
        this.biome = biome || new CustomBiome(stringId + "_biome");
        if ("getLayers" in this) {
            this.layers = this.getLayers();
        }
        var tags = this.getTags();
        if (tags != null) {
            TagRegistry.addCommonObject("dimensions", this.id, tags);
        }
        this.dimension.setGenerator(this.getGenerator());
        if ("getSkyColor" in this) {
            var skyColor = this.getSkyColor();
            this.dimension.setSkyColor(skyColor[0], skyColor[1], skyColor[2]);
        }
        if ("getFogColor" in this) {
            var fogColor = this.getFogColor();
            this.dimension.setFogColor(fogColor[0], fogColor[1], fogColor[2]);
        }
        if ("getCloudColor" in this) {
            var cloudColor = this.getCloudColor();
            this.dimension.setCloudColor(cloudColor[0], cloudColor[1], cloudColor[2]);
        }
        if ("getSunsetColor" in this) {
            var sunsetColor = this.getSunsetColor();
            this.dimension.setSunsetColor(sunsetColor[0], sunsetColor[1], sunsetColor[2]);
        }
        if ("getFogDistance" in this) {
            var fogDistance = this.getFogDistance();
            this.dimension.setFogDistance(fogDistance[0], fogDistance[1]);
        }
        if ("hasSkyLight" in this) {
            this.dimension.setHasSkyLight(this.hasSkyLight);
        }
        if (this.getSkyAtmosphereEnabled()) {
            if ("hasMoon" in this) {
                Dimensions.setShouldRenderMoon(this.dimension.id, this.hasMoon);
            }
            if ("hasSun" in this) {
                Dimensions.setShouldRenderSun(this.dimension.id, this.hasSun);
            }
            if ("hasStars" in this) {
                Dimensions.setShouldRenderStars(this.dimension.id, this.hasStars);
            }
            if ("hasClouds" in this) {
                Dimensions.setShouldRenderClouds(this.dimension.id, this.hasClouds);
            }
            if ("getStarBrightness" in this) {
                this.dimension.setStarBrightness(this.getStarBrightness());
            }
        }
        else
            this.dimension.setSkyAtmosphereEnabled(false);
        if ("hasVanillaWeather" in this) {
            Dimensions.setWeatherSeasons(this.dimension.id, this.hasVanillaWeather);
        }
        if ("getDayTimeInterval" in this) {
            this.dimension.setTimeOfDay(this.getDayTimeInterval());
        }
        if ("canEvaporatesLiquids" in this) {
            this.dimension.setEvaporatesLiquids(this.canEvaporatesLiquids);
        }
        if ("generateDimensionChunk" in this) {
            BasicDimension.generateChunkFunctions[this.id] = this.generateDimensionChunk;
        }
        if ("insidePlayerDimensionTransfer" in this) {
            BasicDimension.insideTransferFunctions[this.id] = this.onInsideEntityTransfer;
        }
        if ("outsidePlayerDimensionTransfer" in this) {
            BasicDimension.outsideTransferFunctions[this.id] = this.onOutsideEntityTransfer;
        }
    }
    BasicDimension.prototype.addLayer = function (layer) {
        this.layers.push(layer);
        this.dimension.setGenerator(this.getGenerator());
    };
    BasicDimension.prototype.getSkyAtmosphereEnabled = function () {
        return true;
    };
    BasicDimension.prototype.getGenerator = function () {
        var object = {
            biome: this.biome.id,
            layers: this.hasBedrockLayer ?
                this.layers.concat({
                    minY: 0,
                    maxY: 1,
                    yConversion: [[0.7, 1]],
                    material: { base: VanillaBlockID.bedrock },
                }) : this.layers
        };
        if ("getBase" in this) {
            object.base = this.getBase();
        }
        if ("modWorldgenDimension" in this) {
            object.modWorldgenDimension = this.modWorldgenDimension();
        }
        if ("getType" in this) {
            object.type = this.getType();
        }
        object.generateVanillaStructures = this.generateVanillaStructures();
        object.buildVanillaSurfaces = this.buildVanillaSurfaces();
        var generator = Dimensions.newGenerator(object);
        var generateCaves = this.generateCaves();
        generator.setGenerateCaves(generateCaves[0], generateCaves[1]);
        return Dimensions.newGenerator(object);
    };
    BasicDimension.prototype.getTags = function () {
        return null;
    };
    BasicDimension.prototype.buildVanillaSurfaces = function () {
        return false;
    };
    BasicDimension.prototype.generateCaves = function () {
        return [false, false];
    };
    BasicDimension.prototype.generateVanillaStructures = function () {
        return false;
    };
    BasicDimension.generateChunkFunctions = {};
    BasicDimension.insideTransferFunctions = {};
    BasicDimension.outsideTransferFunctions = {};
    return BasicDimension;
}());
Callback.addCallback("CustomDimensionTransfer", function (entityUid, from, to) {
    if (to in BasicDimension.insideTransferFunctions) {
        BasicDimension.insideTransferFunctions[to](entityUid, from);
    }
    if (from in BasicDimension.outsideTransferFunctions) {
        BasicDimension.outsideTransferFunctions[from](entityUid, to);
    }
});
Callback.addCallback("GenerateCustomDimensionChunk", function (chunkX, chunkZ, random, dimensionId) {
    if (dimensionId in BasicDimension.generateChunkFunctions) {
        return BasicDimension.generateChunkFunctions[dimensionId](chunkX, chunkZ, random);
    }
});
/**
 * Enum with names of all callbacks
 */
var ECallback;
(function (ECallback) {
    ECallback["CRAFT_RECIPE_PRE_PROVIDED"] = "CraftRecipePreProvided";
    ECallback["CRAFT_RECIPE_PROVIDED_FUNCTION"] = "CraftRecipeProvidedFunction";
    ECallback["VANILLA_WORKBENCH_CRAFT"] = "VanillaWorkbenchCraft";
    ECallback["VANILLA_WORKBENCH_POST_CRAFT"] = "VanillaWorkbenchPostCraft";
    ECallback["VANILLA_WORKBENCH_RECIPE_SELECTED"] = "VanillaWorkbenchRecipeSelected";
    ECallback["CONTAINER_CLOSED"] = "ContainerClosed";
    ECallback["CONTAINER_OPENED"] = "ContainerOpened";
    ECallback["CUSTOM_WINDOW_OPENED"] = "CustomWindowOpened";
    ECallback["CUSTOM_WINDOW_CLOSED"] = "CustomWindowClosed";
    ECallback["CORE_CONFIGURED"] = "CoreConfigured";
    ECallback["PRE_LOADED"] = "PreLoaded";
    ECallback["API_LOADED"] = "APILoaded";
    ECallback["MODS_LOADED"] = "ModsLoaded";
    ECallback["POST_LOADED"] = "PostLoaded";
    ECallback["PRE_BLOCKS_DEFINED"] = "PreBlocksDefined";
    ECallback["BLOCKS_DEFINED"] = "BlocksDefined";
    ECallback["ADD_RUNTIME_PACKS"] = "AddRuntimePacks";
    ECallback["LEVEL_SELECTED"] = "LevelSelected";
    ECallback["DIMENSION_LOADED"] = "DimensionLoaded";
    ECallback["DESTROY_BLOCK_END"] = "DestroyBlock";
    ECallback["DESTROY_BLOCK_START"] = "DestroyBlockStart";
    ECallback["DESTROY_BLOCK_CONTINUE"] = "DestroyBlockContinue";
    ECallback["BUILD_BLOCK"] = "BuildBlock";
    ECallback["BLOCK_CHANGED"] = "BlockChanged";
    ECallback["BREAK_BLOCK"] = "BreakBlock";
    ECallback["ITEM_USE"] = "ItemUse";
    ECallback["ITEM_USE_LOCAL_SERVER"] = "ItemUseLocalServer";
    ECallback["EXPLOSION"] = "Explosion";
    ECallback["FOOD_EATEN"] = "FoodEaten";
    ECallback["EXP_ADD"] = "ExpAdd";
    ECallback["EXP_LEVEL_ADD"] = "ExpLevelAdd";
    ECallback["NATIVE_COMMAND"] = "NativeCommand";
    ECallback["PLAYER_ATTACK"] = "PlayerAttack";
    ECallback["ENTITY_ADDED"] = "EntityAdded";
    ECallback["ENTITY_REMOVED"] = "EntityRemoved";
    ECallback["ENTITY_ADDED_LOCAL"] = "EntityAddedLocal";
    ECallback["ENTITY_REMOVED_LOCAL"] = "EntityRemovedLocal";
    ECallback["ENTITY_DEATH"] = "EntityDeath";
    ECallback["ENTITY_HURT"] = "EntityHurt";
    ECallback["ENTITY_INTERACT"] = "EntityInteract";
    ECallback["EXP_ORBS_SPAWNED"] = "ExpOrbsSpawned";
    ECallback["PROJECTILE_HIT"] = "ProjectileHit";
    ECallback["REDSTONE_SIGNAL"] = "RedstoneSignal";
    ECallback["POP_BLOCK_RESOURCES"] = "PopBlockResources";
    ECallback["ITEM_ICON_OVERRIDE"] = "ItemIconOverride";
    ECallback["ITEM_NAME_OVERRIDE"] = "ItemNameOverride";
    ECallback["ITEM_USE_NO_TARGET"] = "ItemUseNoTarget";
    ECallback["ITEM_USING_RELEASED"] = "ItemUsingReleased";
    ECallback["ITEM_USING_COMPLETE"] = "ItemUsingComplete";
    ECallback["ITEM_DISPENSED"] = "ItemDispensed";
    ECallback["NATIVE_GUI_CHANGED"] = "NativeGuiChanged";
    ECallback["ENCHANT_POST_ATTACK"] = "EnchantPostAttack";
    ECallback["ENCHANT_GET_PROTECTION_BONUS"] = "EnchantGetProtectionBonus";
    ECallback["ENCHANT_GET_DAMAGE_BONUS"] = "EnchantGetDamageBonus";
    ECallback["ENCHANT_POST_HURT"] = "EnchantPostHurt";
    ECallback["GENERATE_CHUNK"] = "GenerateChunk";
    ECallback["GENERATE_CHUNK_UNDERGROUND"] = "GenerateChunkUnderground";
    ECallback["GENERATE_NETHER_CHUNK"] = "GenerateNetherChunk";
    ECallback["GENERATE_END_CHUNK"] = "GenerateEndChunk";
    ECallback["GENERATE_CHUNK_UNIVERSAL"] = "GenerateChunkUniversal";
    ECallback["GENERATE_BIOME_MAP"] = "GenerateBiomeMap";
    ECallback["PRE_PROCESS_CHUNK"] = "PreProcessChunk";
    ECallback["POST_PROCESS_CHUNK"] = "PostProcessChunk";
    ECallback["READ_SAVES"] = "ReadSaves";
    ECallback["WRITE_SAVES"] = "WriteSaves";
    ECallback["CUSTOM_BLOCK_TESSELLATION"] = "CustomBlockTessellation";
    ECallback["LOCAL_PLAYER_TICK"] = "LocalPlayerTick";
    ECallback["SERVER_PLAYER_TICK"] = "ServerPlayerTick";
    ECallback["CUSTOM_DIMENSION_TRANSFER"] = "CustomDimensionTransfer";
    ECallback["BLOCK_EVENT_ENTITY_INSIDE"] = "BlockEventEntityInside";
    ECallback["BLOCK_EVENT_ENTITY_STEP_ON"] = "BlockEventEntityStepOn";
    ECallback["BLOCK_EVENT_NEIGHBOUR_CHANGE"] = "BlockEventNeighbourChange";
    ECallback["CONNECTING_TO_HOST"] = "ConnectingToHost";
    ECallback["DIMENSION_UNLOADED"] = "DimensionUnloaded";
    ECallback["LEVEL_PRE_LEFT"] = "LevelPreLeft";
    ECallback["GAME_LEFT"] = "GameLeft";
    ECallback["LEVEL_LEFT"] = "LevelLeft";
    ECallback["LOCAL_LEVEL_LEFT"] = "LocalLevelLeft";
    ECallback["LOCAL_LEVEL_PRE_LEFT"] = "LocalLevelPreLeft";
    ECallback["SERVER_LEVEL_LEFT"] = "ServerLevelLeft";
    ECallback["SERVER_LEVEL_PRE_LEFT"] = "ServerLevelPreLeft";
    ECallback["ITEM_USE_LOCAL"] = "ItemUseLocal";
    ECallback["SYSTEM_KEY_EVENT_DISPATCHED"] = "SystemKeyEventDispatched";
    ECallback["NAVIGATION_BACK_PRESSED"] = "NavigationBackPressed";
    ECallback["LEVEL_CREATED"] = "LevelCreated";
    ECallback["LEVEL_DISPLAYED"] = "LevelDisplayed";
    ECallback["LEVEL_PRE_LOADED"] = "LevelPreLoaded";
    ECallback["LEVEL_LOADED"] = "LevelLoaded";
    ECallback["LOCAL_LEVEL_LOADED"] = "LocalLevelLoaded";
    ECallback["REMOTE_LEVEL_LOADED"] = "RemoteLevelLoaded";
    ECallback["REMOTE_LEVEL_PRE_LOADED"] = "RemoteLevelPreLoaded";
    ECallback["SERVER_LEVEL_LOADED"] = "ServerLevelLoaded";
    ECallback["SERVER_LEVEL_PRE_LOADED"] = "ServerLevelPreLoaded";
    ECallback["TICK"] = "tick";
    ECallback["LOCAL_TICK"] = "LocalTick";
    ECallback["APP_SUSPENDED"] = "AppSuspended";
    ECallback["ENTITY_PICK_UP_DROP"] = "EntityPickUpDrop";
    ECallback["LOCAL_PLAYER_LOADED"] = "LocalPlayerLoaded";
    ECallback["SERVER_PLAYER_LOADED"] = "ServerPlayerLoaded";
    ECallback["SERVER_PLAYER_LEFT"] = "ServerPlayerLeft";
    ECallback["LOCAL_PLAYER_CHANGED_DIMENSION"] = "LocalPlayerChangedDimension";
    ECallback["PLAYER_CHANGED_DIMENSION"] = "PlayerChangedDimension";
    ECallback["LOCAL_PLAYER_EAT"] = "LocalPlayerEat";
    ECallback["SERVER_PLAYER_EAT"] = "ServerPlayerEat";
    ECallback["GENERATE_CUSTOM_DIMENSION_CHUNK"] = "GenerateCustomDimensionChunk";
    ECallback["TILE_ENTITY_ADDED"] = "TileEntityAdded";
    ECallback["TILE_ENTITY_REMOVED"] = "TileEntityRemoved";
    /**
     * Custom callback. Works in one time of 8 ticks, if player held the item.
     */
    ECallback["ITEM_HOLD"] = "ItemHold";
    ECallback["SELECTION"] = "Selection";
})(ECallback || (ECallback = {}));
;
function SubscribeEvent(value, key, descriptor) {
    var method = descriptor.value;
    if (arguments.length > 0) {
        return function (value, key, descriptor) {
            Callback.addCallback(value, method, key ? Number(key) : null);
            return descriptor;
        };
    }
    var name = key.replace("on", "");
    Callback.addCallback(name, method);
    return descriptor;
}
ModAPI.registerAPI("FirefliesAPI", {
    MathHelper: MathHelper,
    RenderHelper: RenderHelper,
    RenderSide: RenderSide,
    BlockAnimation: BlockAnimation,
    EDestroyLevel: EDestroyLevel,
    Vector3: Vector3,
    ItemStack: ItemStack,
    BasicBlock: BasicBlock,
    BlockModel: BlockModel,
    BlockPlant: BlockPlant,
    BlockBush: BlockBush,
    Keyboard: Keyboard,
    UIHelper: UIHelper,
    PlayerUser: PlayerUser,
    Bark: Bark,
    Hewn: Hewn,
    Log: Log,
    Planks: Planks,
    RotatableLog: RotatableLog,
    BasicItem: BasicItem,
    CommonTileEntity: CommonTileEntity,
    LocalTileEntity: LocalTileEntity,
    NetworkEvent: NetworkEvent,
    ContainerEvent: ContainerEvent,
    BasicDimension: BasicDimension,
    RuntimeData: RuntimeData,
    EScreenName: EScreenName,
    ECallback: ECallback,
    ESide: ESide,
    WorldRenderObject: WorldRenderObject,
    SubscribeEvent: SubscribeEvent,
    requireGlobal: function (command) {
        return eval(command);
    }
});
